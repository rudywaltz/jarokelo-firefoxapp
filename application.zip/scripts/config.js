'use strict';
angular.module('configuration', []).constant('API_SERVER_ENDPOINT',
 'http://sandbox.odkazprestarostu.sk');