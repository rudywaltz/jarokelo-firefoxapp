'use strict';
//live-site:  http://www.odkazprestarostu.sk'
angular.module('configuration', []).constant('API_SERVER_ENDPOINT',
 'http://sandbox.odkazprestarostu.sk');