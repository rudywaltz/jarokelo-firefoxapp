'use strict';

angular.module('jarokeloApp')
  .directive('status', function () {
    return {
      restrict: 'C',
    };
  });
